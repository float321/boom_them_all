from flask import Flask, render_template, request, redirect, session
from flask import make_response, sessions
import flask

from data import db_session
from data.news import News
from data.users_api import init_login_manager
from data import news_api

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

@app.route("/")
def index():
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.is_private != True)
    return render_template("index.html", news=news)

@app.route("/cookie_test")
def cookie_test():
    visits_count = int(request.cookies.get("visits_count", 0))
    db_sess = db_session.create_session()
    news = db_sess.query(News).filter(News.is_private != True)
    if visits_count:
        res = make_response(
            render_template("index.html", news=news))
        res.set_cookie("visits_count", str(visits_count + 1),
                       max_age=60 * 60 * 24 * 365 * 2)
    else:
        res = make_response(
            render_template("index.html", news=news))
        res.set_cookie("visits_count", '1',
                       max_age=60 * 60 * 24 * 365 * 2)
    return res

@app.route("/session_test")
def session_test():
    visits_count = session.get('visits_count', 0)
    session['visits_count'] = visits_count + 1
    return make_response(
        f"Вы пришли на эту страницу {visits_count + 1} раз")

@app.errorhandler(404)
def not_found(error):
    return make_response(flask.jsonify({'error': 'Not found'}), 404)


@app.errorhandler(400)
def bad_request(_):
    return make_response(flask.jsonify({'error': 'Bad Request'}), 400)

def main():
    db_session.global_init("db/blogs.db")
    init_login_manager(app)
    app.register_blueprint(news_api.blueprint)
    app.run(port=8000)
    '''
    db_sess = db_session.create_session()
    for i in range(1, 5):
        user = User()
        user.name = f"Пользователь {i}"
        user.about = f"биография пользователя {i}"
        user.email = f"email{i}@email.ru"
        db_sess.add(user)

        news = News(title=f"{i} новость", content="Привет блог!", 
                user_id=i, is_private=False)
        db_sess.add(news)
    db_sess.commit()'
    '''


if __name__ == '__main__':
    main()